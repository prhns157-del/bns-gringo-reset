import{c}from"./index-BhN0l3GJ.js";import{u as r,r as t}from"./react-vendor-MgKJhORd.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=c("CircleHelp",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]]),p=(a="/")=>{const e=r();return t.useCallback(()=>{window.history.length>1?e(-1):e(a)},[e,a])};export{i as C,p as u};
